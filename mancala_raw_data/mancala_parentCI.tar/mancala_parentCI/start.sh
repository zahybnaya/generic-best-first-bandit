./distribute_exections.sh "~/Thesis/mancala_parentCI" "python distributer.py tasks" 
